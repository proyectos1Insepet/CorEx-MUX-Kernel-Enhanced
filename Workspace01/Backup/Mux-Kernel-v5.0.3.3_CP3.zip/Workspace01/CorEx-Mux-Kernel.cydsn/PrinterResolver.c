/* ========================================
 *
 * Copyright INSEPET SISTEMAS, 2016
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
@Created By: HIJH
@Date: Septembre de 2016
*/

#include "Dispenser.h"
#include "UARTManager.h"

//@Created By: HIJH
//@Date: Septembre de 2016
//DEPRECATED
void PrinterUARTSend(void *ptr)
{
}

/* [] END OF FILE */
